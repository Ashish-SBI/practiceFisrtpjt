import React from "react";

const ContactList = ({ contacts }) => {
  console.log(contacts);
  const renderContactLlist = contacts.map((item, index) => {
    return (
      <div className="item">
        <div className="header">
          <div>{item.name}</div>
          <div>{item.email}</div>
        </div>
      </div>
    );
  });
  return <div className="ui celled list">ContactList</div>;
};

export default ContactList;
